﻿Public Class Form1
    Dim img As Graphics 'display
    Dim imgColor As Color
    Dim vList() As Point3D 'vertexlist
    Dim vertIndex As Integer 'indexvert
    Dim polyIndex As Integer 'index pol
    Dim rMatrix(3, 3) As Double
    Dim sCenterX, sCenterY As Integer 'xy center

    Class Point3D
        Public x, y, z As Double
        Public index As Integer

        Public Sub New()
            index = -1 'pas masuk d array mulai dr 0 (subaddvertex)
            x = 0.0
            y = 0.0
            z = 0.0
        End Sub

        Public Sub New(Newindex As Integer, Newx As Double, Newy As Double, Newz As Double)
            'point berdasar parameter
            index = Newindex
            x = Newx
            y = Newy
            z = Newz
        End Sub

        Public Function ToVector() As Vector3D
            Return New Vector3D(x, y, z) 'point->vector
        End Function

        Public Overrides Function ToString() As String
            Return (index + 1).ToString + " (" + x.ToString + ", " + y.ToString + ", " + z.ToString + ")" 'listboxx
        End Function
    End Class

    'Class polyVertex 'polygon
    '    Public vertIndex As Integer
    '    Public vertNext As polyVertex
    'End Class

    Class Polygon3D
        Public vertIndex() As Integer 'indexvertex
        Public vertCount As Integer 'vertex berapa
        Public polyIndex As Integer 'indexpoly
        Public polyNormal As Vector3D

        Public Sub New()
            vertIndex = Nothing
            vertCount = -1 'arr
            polyIndex = -1
            polyNormal = Nothing
        End Sub

        Public Sub Add(Newindex As Integer) 'addvertex 123
            vertCount += 1
            ReDim Preserve vertIndex(vertCount) 'resize array
            vertIndex(vertCount) = Newindex
        End Sub

        Public Sub Iterate()
            For i = 0 To vertCount
                Console.WriteLine(vertIndex(i))
            Next
        End Sub

        Public Overrides Function ToString() As String
            Return "Polygon " + (polyIndex).ToString
        End Function
    End Class

    Class Vector3D
        Public x, y, z As Double

        Public Sub New()
            x = 0.0
            y = 0.0
            z = 0.0
        End Sub

        Public Sub New(Newx As Double, Newy As Double, Newz As Double)
            x = Newx
            y = Newy
            z = Newz
        End Sub

        Public Sub New(p As Point3D)
            Me.x = p.x
            Me.y = p.y
            Me.z = p.z
        End Sub

        'Public Function DotProduct(v As Vector3D) As Double
        '    Return (Me.x * v.x + Me.y * v.y + Me.z * v.z)
        'End Function

        'Public Function GetMagnitude() As Double
        '    Return Math.Sqrt(DotProduct(Me))
        'End Function

        'Public Function Minus(v As Vector3D) As Vector3D
        '    'nambah vertex setelah ada polygon, renormalize
        '    Dim vOut As New Vector3D
        '    vOut.x = v.x - Me.x
        '    vOut.y = v.y - Me.y
        '    vOut.z = v.z - Me.z

        '    Return vOut
        'End Function

        'Public Function CrossProduct(v As Vector3D) As Vector3D
        '    'formula crossprod
        '    Dim vOut As New Vector3D With {
        '        .x = Me.y * v.z - Me.z * v.y,
        '        .y = Me.z * v.x - Me.x * v.z,
        '        .z = Me.x * v.y - Me.y * v.x
        '    }

        'Return vOut
        'End Function

        '    Public Function Normalize() As Vector3D
        '        Dim mag As Double = Me.GetMagnitude

        '        If mag > 0 Then
        '            Me.x /= mag
        '            Me.y /= mag
        '            Me.z /= mag
        '        End If
        '        Return Me
        '    End Function
    End Class

    Sub SetMatrixRow(ByRef mtx(,) As Double, index As Integer, a As Double, b As Double, c As Double, d As Double)
        mtx(index, 0) = a
        mtx(index, 1) = b
        mtx(index, 2) = c
        mtx(index, 3) = d
    End Sub

    Sub RotateObj(vlist() As Point3D, Newindex As Integer, mtx(,) As Double, ByRef isrotated() As Boolean)
        Dim temp As New Point3D 'kaliin matrixnya umum, specify d bawah sin teta etc
        If Not isrotated(Newindex) Then
            temp.x = vlist(Newindex).x * mtx(0, 0) + vlist(Newindex).y * mtx(1, 0) + vlist(Newindex).z * mtx(2, 0)
            temp.y = vlist(Newindex).x * mtx(0, 1) + vlist(Newindex).y * mtx(1, 1) + vlist(Newindex).z * mtx(2, 1)
            temp.z = vlist(Newindex).x * mtx(0, 2) + vlist(Newindex).y * mtx(1, 2) + vlist(Newindex).z * mtx(2, 2)
            isrotated(Newindex) = True
            vlist(Newindex) = temp
        End If
    End Sub

    'Sub ToPerspective(vlist() As Point3D, Newindex As Integer, istransformed() As Boolean)
    '    Dim temp As New Point3D

    '    If Not istransformed(Newindex) Then
    '        temp.x = vlist(Newindex).x * 1 + vlist(Newindex).y * 0 + vlist(Newindex).z * 0 + 1 * 0
    '        temp.y = vlist(Newindex).x * 0 + vlist(Newindex).y * 1 + vlist(Newindex).z * 0 + 1 * 0
    '        temp.z = vlist(Newindex).x * 0 + vlist(Newindex).y * 0 + vlist(Newindex).z * 1 + 1 * -0.2
    '        istransformed(Newindex) = True
    '        vlist(Newindex) = temp
    '    End If
    'End Sub

    'Sub ScaleObj(vlist() As Point3D, Newindex As Integer, scale As Double, ByRef isscaled() As Boolean)
    '    Dim temp As New Point3D

    '    If Not isscaled(Newindex) Then
    '        temp.x = (vlist(Newindex).x * scale) + (vlist(Newindex).y * 0) + (vlist(Newindex).z * 0)
    '        temp.y = (vlist(Newindex).x * 0) + (vlist(Newindex).y * scale) + (vlist(Newindex).z * 0)
    '        temp.z = (vlist(Newindex).x * 0) + (vlist(Newindex).y * 0) + (vlist(Newindex).z * scale)
    '        isscaled(Newindex) = True
    '        vlist(Newindex) = temp
    '    End If
    'End Sub

    Sub AddVertex(ByRef vList() As Point3D, ByRef Newindex As Integer, Newx As Double, Newy As Double, Newz As Double)
        Newindex += 1 'add point vertex to arr
        ReDim Preserve vList(Newindex)
        vList(Newindex) = New Point3D(Newindex, Newx, Newy, Newz)
    End Sub

    'Function GetNormalVector(Newp1 As Point3D, Newp2 As Point3D, Newp3 As Point3D)
    '    Dim p1 As Vector3D = Newp2.ToVector.Minus(Newp1.ToVector) 'new v d minus
    '    Dim p2 As Vector3D = Newp3.ToVector.Minus(Newp2.ToVector)
    '    p1.Normalize()
    '    p2.Normalize()

    '    Return p1.CrossProduct(p2)
    'End Function

    'Function BackFaceCulling(Newp0 As Point3D, Newp1 As Point3D, Newp2 As Point3D)
    '    Dim viewer As New Vector3D(0.0, 0.0, 1.0)

    '    If viewer.DotProduct(GetNormalVector(Newp0, Newp1, Newp2)) > 0.0 Then
    '        Return True
    '    Else
    '        Return False
    '    End If
    'End Function

    Sub DrawMesh(img As Graphics, cX As Integer, cY As Integer, ByRef lBox As Object, ByRef vlist() As Point3D, Newindex As Integer, Newcolor As Color, bfCulling As Boolean)
        img.Clear(Color.White)
        Dim isTransformed(Newindex) As Boolean

        For i = 0 To Newindex
            isTransformed(i) = False
        Next

        For i = 0 To lBox.Count - 1
            For j = 0 To lBox(i).vertCount - 1
                ''ToPerspective(vlist, lBox(i).vertIndex(j), isTransformed)
                'If bfCulling = True Then
                '    If BackFaceCulling(vlist(lBox(i).vertIndex(0)), vlist(lBox(i).vertIndex(1)), vlist(lBox(i).vertIndex(2))) Then
                '        img.DrawLine(New Pen(Newcolor), CInt(vlist(lBox(i).vertIndex(j)).x) + cX, -CInt(vlist(lBox(i).vertIndex(j)).y) + cY, CInt(vlist(lBox(i).vertIndex(j + 1)).x) + cX, -CInt(vlist(lBox(i).vertIndex(j + 1)).y) + cY)
                '    Else
                '        Continue For
                '    End If
                'Else
                img.DrawLine(New Pen(Newcolor), CInt(vlist(lBox(i).vertIndex(j)).x) + cX, -CInt(vlist(lBox(i).vertIndex(j)).y) + cY, CInt(vlist(lBox(i).vertIndex(j + 1)).x) + cX, -CInt(vlist(lBox(i).vertIndex(j + 1)).y) + cY)
                'End If
            Next
            'If bfCulling = True Then
            '    If BackFaceCulling(vlist(lBox(i).vertIndex(lBox(i).vertCount - 2)), vlist(lBox(i).vertIndex(lBox(i).vertCount - 1)), vlist(lBox(i).vertIndex(lBox(i).vertCount))) Then
            '        img.DrawLine(New Pen(Newcolor), CInt(vlist(lBox(i).vertIndex(lBox(i).vertCount)).x) + cX, -CInt(vlist(lBox(i).vertIndex(lBox(i).vertCount)).y) + cY, CInt(vlist(lBox(i).vertIndex(0)).x) + cX, -CInt(vlist(lBox(i).vertIndex(0)).y) + cY)
            '    Else
            '        Continue For
            '    End If
            'Else
            img.DrawLine(New Pen(Newcolor), CInt(vlist(lBox(i).vertIndex(lBox(i).vertCount)).x) + cX, -CInt(vlist(lBox(i).vertIndex(lBox(i).vertCount)).y) + cY, CInt(vlist(lBox(i).vertIndex(0)).x) + cX, -CInt(vlist(lBox(i).vertIndex(0)).y) + cY)
            'End If
        Next
        'Dim nVector As Vector3D = GetNormalVector(vlist(lBox(0).vertIndex(0)), vlist(lBox(0).vertIndex(1)), vlist(lBox(0).vertIndex(2)))
        'img.DrawLine(New Pen(Color.Red), CInt(nVector.x) + cX, -CInt(nVector.y) + cY, CInt(nVector.x) + 50 + cX, -(CInt(nVector.y) + 50) + cY)
    End Sub

    Private Sub Form1NewLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        img = PictureBox1.CreateGraphics
        imgColor = Color.Black
        sCenterX = PictureBox1.Width / 2
        sCenterY = PictureBox1.Height / 2
        vertIndex = -1
        polyIndex = 0
    End Sub

    Private Sub PictureBox1NewMouseMove(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseMove
        Label1.Text = "X: " + (e.X - sCenterX).ToString
        Label2.Text = "Y: " + (-1 * (e.Y - sCenterY)).ToString
    End Sub

    Private Sub btnVertxNewClick(sender As Object, e As EventArgs) Handles btnVertx.Click
        AddVertex(vList, vertIndex, CDbl(NumericUpDown1.Text), CDbl(NumericUpDown2.Text), CDbl(NumericUpDown3.Text))

        vertex.Items.Add(vList(vertIndex))
        'Console.WriteLine(vertIndex.ToString + " " + vList(vertIndex).x.ToString + " " + vList(vertIndex).y.ToString + " " + vList(vertIndex).z.ToString)
    End Sub

    Private Sub btnPolygonNewClick(sender As Object, e As EventArgs) Handles btnPolygon.Click
        AddVertex(vList, vertIndex, CDbl(NumericUpDown4.Text), CDbl(NumericUpDown5.Text), CDbl(NumericUpDown6.Text))
        AddVertex(vList, vertIndex, CDbl(NumericUpDown7.Text), CDbl(NumericUpDown8.Text), CDbl(NumericUpDown9.Text))
        AddVertex(vList, vertIndex, CDbl(NumericUpDown10.Text), CDbl(NumericUpDown11.Text), CDbl(NumericUpDown12.Text))

        vertex.Items.Add(vList(vertIndex - 2))
        vertex.Items.Add(vList(vertIndex - 1))
        vertex.Items.Add(vList(vertIndex))

        Dim p As New Polygon3D

        For i = vertIndex - 2 To vertIndex
            p.Add(vList(i).index)
            vertex.SetItemChecked(i, True)
        Next

        polyIndex += 1
        p.polyIndex = polyIndex
        polygon.Items.Add(p)
        polygon.SelectedIndex = 0
    End Sub

    Private Sub btnVertoPolNewClick(sender As Object, e As EventArgs) Handles btnVertoPol.Click
        If polygon.Items.Count <> 0 Then
            Dim p As New Polygon3D
            Dim Newindex As Integer = polygon.SelectedIndex

            For i = 0 To vertex.CheckedItems.Count - 1
                p.Add(vertex.CheckedItems(i).index)
            Next

            p.polyIndex = polyIndex
            polygon.Items.Remove(polygon.SelectedItem)
            polygon.Items.Insert(Newindex, p)
            polygon.SelectedIndex = 0
        End If
    End Sub

    Private Sub btnRotateeNewClick(sender As Object, e As EventArgs) Handles btnRotatee.Click
        Dim dx As Integer = CInt(NumericUpDown13.Text)
        Dim dy As Integer = CInt(NumericUpDown14.Text)
        Dim dz As Integer = CInt(NumericUpDown15.Text)
        Dim isRotated(vertIndex) As Boolean

        For i = 0 To vertIndex
            isRotated(i) = False
        Next

        SetMatrixRow(rMatrix, 0, Math.Cos(dy * Math.PI / 180), 0, -Math.Sin(dy * Math.PI / 180), 0)
        SetMatrixRow(rMatrix, 1, 0, 1, 0, 0)
        SetMatrixRow(rMatrix, 2, Math.Sin(dy * Math.PI / 180), 0, Math.Cos(dx * Math.PI / 180), 0)
        SetMatrixRow(rMatrix, 3, 0, 0, 0, 1)

        For i = 0 To polygon.Items.Count - 1
            For j = 0 To polygon.Items(i).vertCount
                RotateObj(vList, polygon.Items(i).vertIndex(j), rMatrix, isRotated)
            Next
        Next

        DrawMesh(img, sCenterX, sCenterY, polygon.Items, vList, vertIndex, imgColor, CheckBox1.Checked)
    End Sub

    Private Sub btnDrawClick(sender As Object, e As EventArgs) Handles btnDraw.Click
        If polygon.Items.Count <> 0 Then
            DrawMesh(img, sCenterX, sCenterY, polygon.Items, vList, vertIndex, imgColor, CheckBox1.Checked)
        End If
    End Sub

    Private Sub ListBox1NewSelectedIndexChanged(sender As Object, e As EventArgs) Handles polygon.SelectedIndexChanged
        allvertex.Items.Clear()

        If polygon.Items.Count <> 0 Then
            ComboBox1.Enabled = True
            ComboBox2.Enabled = True
        Else
            ComboBox1.Enabled = False
            ComboBox2.Enabled = False
        End If

        If polygon.SelectedIndex <> -1 Then
            For i = 0 To polygon.SelectedItem.vertCount
                allvertex.Items.Add(vList(polygon.SelectedItem.vertIndex(i)))
            Next
            allvertex.SelectedIndex = 0
        End If
    End Sub

    Private Sub ListBox2NewSelectedIndexChanged(sender As Object, e As EventArgs) Handles allvertex.SelectedIndexChanged
        If allvertex.SelectedIndex > 0 Then
            NumericUpDown16.Text = vList(allvertex.SelectedItem.index).x
            NumericUpDown17.Text = vList(allvertex.SelectedItem.index).y
            NumericUpDown18.Text = vList(allvertex.SelectedItem.index).z

        End If
    End Sub

    Private Sub btnDelPolNewClick(sender As Object, e As EventArgs)
        polygon.Items.Remove(polygon.SelectedItem)
        If polygon.Items.Count <> 0 Then
            polygon.SelectedIndex = 0
        End If
    End Sub

    Private Sub btnEditVerNewClick(sender As Object, e As EventArgs)
        vList(allvertex.SelectedItem.index).x = CInt(NumericUpDown16.Text)
        vList(allvertex.SelectedItem.index).y = CInt(NumericUpDown17.Text)
        vList(allvertex.SelectedItem.index).z = CInt(NumericUpDown18.Text)

        DrawMesh(img, sCenterX, sCenterY, polygon.Items, vList, vertIndex, imgColor, CheckBox1.Checked)
    End Sub

    Private Sub Button9NewClick(sender As Object, e As EventArgs) Handles btnClear.Click
        img.Clear(Color.White)
    End Sub

    Private Sub ListofVertexNewSelectedIndexChanged(sender As Object, e As EventArgs) Handles vertex.SelectedIndexChanged
        'If CheckedListBox1.Items.Count <> 0 Then
        '    NumericUpDown16.Text = vList(CheckedListBox1.CheckedItems(0).index).x
        '    NumericUpDown17.Text = vList(CheckedListBox1.CheckedItems(0).index).y
        '    NumericUpDown18.Text = vList(CheckedListBox1.CheckedItems(0).index).z
        'End If

        'If ListBox2.SelectedIndex <> -1 Then
        '    NumericUpDown16.Text = vList(ListBox2.SelectedItem.index).x
        '    NumericUpDown17.Text = vList(ListBox2.SelectedItem.index).y
        '    NumericUpDown18.Text = vList(ListBox2.SelectedItem.index).z

        'End If
    End Sub

    'Private Sub Button10NewClick(sender As Object, e As EventArgs) Handles Button10.Click
    '    Dim isScaled(vertIndex) As Boolean

    '    For i = 0 To vertIndex
    '        isScaled(i) = False
    '    Next

    '    For i = 0 To ListBox1.Items.Count - 1
    '        For j = 0 To ListBox1.Items(i).vertCount
    '            ScaleObj(vList, ListBox1.Items(i).vertIndex(j), 2, isScaled)
    '        Next
    '    Next

    '    DrawMesh(img, sCenterX, sCenterY, ListBox1.Items, vList, vertIndex, imgColor, CheckBox1.Checked)
    'End Sub

    'Private Sub Button11NewClick(sender As Object, e As EventArgs) Handles Button11.Click
    '    Dim isScaled(vertIndex) As Boolean

    '    For i = 0 To vertIndex
    '        isScaled(i) = False
    '    Next

    '    For i = 0 To ListBox1.Items.Count - 1
    '        For j = 0 To ListBox1.Items(i).vertCount
    '            ScaleObj(vList, ListBox1.Items(i).vertIndex(j), 0.5, isScaled)
    '        Next
    '    Next

    '    DrawMesh(img, sCenterX, sCenterY, ListBox1.Items, vList, vertIndex, imgColor, CheckBox1.Checked)
    'End Sub

    Private Sub CheckBox1NewCheckedChanged(sender As Object, e As EventArgs)
        DrawMesh(img, sCenterX, sCenterY, polygon.Items, vList, vertIndex, imgColor, CheckBox1.Checked) 'vertex yg mau d gambr check
    End Sub


    'Private Sub btnDelPVerNewClick(sender As Object, e As EventArgs) Handles btnDelPVer.Click
    '    If ListBox2.Items.Count > 3 Then
    '        Dim index As Integer = ListBox2.SelectedItem.index
    '        ListBox2.Items.Remove(ListBox2.SelectedItem)

    '        If index < ListBox1.SelectedItem.vertCount Then
    '            For i = index To ListBox1.SelectedItem.vertCount - 1
    '                ListBox1.SelectedItem.vertIndex(i) = ListBox1.SelectedItem.vertIndex(i + 1)
    '            Next
    '        End If
    '        ListBox1.SelectedItem.vertCount -= 1

    '        DrawMesh(img, sCenterX, sCenterY, ListBox1.Items, vList, vertIndex, imgColor, CheckBox1.Checked)
    '        ListBox2.SelectedIndex = 0
    '    End If
    'End Sub
End Class
